#ifndef OSHW1_SIGNALS_H
#define OSHW1_SIGNALS_H

#include "Libs.h"
#include "SmallShell.h"

void ctrlZHandler(int sig_num);
void ctrlCHandler(int sig_num);
void alarmHandler(int sig_num);


#endif //OSHW1_SIGNALS_H
